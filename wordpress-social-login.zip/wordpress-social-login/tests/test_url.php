<?php
/*!
* WordPress Social Login
*
* http://miled.github.io/wordpress-social-login/ | https://github.com/miled/wordpress-social-login
*  (c) 2011-2014 Mohamed Mrassi and contributors | http://wordpress.org/plugins/wordpress-social-login/
*/

class WSL_Test_URL extends WP_UnitTestCase
{
	function setUp()
	{
		parent::setUp();
	}

	function tearDown()
	{
		parent::tearDown();
	}

	function test_wsl_is_https_on()
	{
		$this->assertTrue( true ); // @fixme
	}

	function test_wsl_get_current_url()
	{
		$this->assertTrue( true ); // @fixme
	}
}
