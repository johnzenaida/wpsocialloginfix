<?php
// credit to: http://hp.nonip.info/wiki/work/index.php?php%2FHybridAuth
class Hybrid_Providers_Mixi extends Hybrid_Provider_Model_OpenID
{
	var $openidIdentifier = "https://mixi.jp";
}
