<?php
/*!
* WordPress Social Login
*
* https://miled.github.io/wordpress-social-login | http://github.com/miled/wordpress-social-login
*  (c) 2011-2014 Mohamed Mrassi and contributors | http://wordpress.org/extend/plugins/wordpress-social-login/
*/

define( 'WORDPRESS_SOCIAL_LOGIN_CUSTOM_ENDPOINT', 'Live' );

require_once( "../index.php" );
